export JAVA_HOME=${JAVA_HOME_OPENJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}
export http_proxy=http://sjc1intproxy01.crd.ge.com:8080
export https_proxy=$http_proxy


buildNumber=$1

mvn clean deploy -U -s predix_settings.xml

if [ $1 ]; then
	mvn -U -s predix_settings.xml deploy -Dci.build.number=${buildNumber}
else 
	mvn -U -s predix_settings.xml deploy
fi
