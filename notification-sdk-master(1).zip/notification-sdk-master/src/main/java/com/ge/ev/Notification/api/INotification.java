package com.ge.ev.Notification.api;

import java.io.Serializable;

import com.ge.ev.Notification.model.AttachmentResource;

public interface INotification extends Serializable{

	public void setFrom(String fromName, String fromEmail) throws Exception;
	
	public void setRecipient(String recipientName, String recipientEmail, String recipientType) throws Exception;
	
	public void setHeader(String key, String value) throws Exception;
	
	public void setSubject(String subject) throws Exception;
	
	public void setAttachment(String attachmentName, String attachmentExtn, String contentType, AttachmentResource attachmentResource) throws Exception;
	
	public void setMessageType(String messageType) throws Exception;
	
	public void setMessageImportant(boolean important) throws Exception;
	
	public void setMessageBody(String messageText) throws Exception;
	
	public void setAppDomain(String appDomain) throws Exception;
	
	public void setAuditTrial(boolean audit) throws Exception;
}
