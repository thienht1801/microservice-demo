package com.ge.ev.Notification.model;

import java.io.Serializable;

public class MailConfiguration implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4764996994057588854L;
	public String protocol;
	public String host;
	public int port;
	public String smtpAuth;
	public String smtpStarttlsEnable;
	public String mailFrom;
	public String mailUsername;
	public String mailPassword;
	public String mailReturnPath;

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getSmtpAuth() {
		return smtpAuth;
	}

	public void setSmtpAuth(String smtpAuth) {
		this.smtpAuth = smtpAuth;
	}

	public String getSmtpStarttlsEnable() {
		return smtpStarttlsEnable;
	}

	public void setSmtpStarttlsEnable(String smtpStarttlsEnable) {
		this.smtpStarttlsEnable = smtpStarttlsEnable;
	}

	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public String getMailUsername() {
		return mailUsername;
	}

	public void setMailUsername(String mailUsername) {
		this.mailUsername = mailUsername;
	}

	public String getMailPassword() {
		return mailPassword;
	}

	public void setMailPassword(String mailPassword) {
		this.mailPassword = mailPassword;
	}

	public String getMailReturnPath() {
		return mailReturnPath;
	}

	public void setMailReturnPath(String mailReturnPath) {
		this.mailReturnPath = mailReturnPath;
	}

}
