package com.ge.ev.Notification.model;

import java.io.Serializable;

public class Attachment implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2416096745213238597L;

	private String attachmentName;

	private String extension;
	
	private String contentType;
	
	private byte[] attchmentBytes = null;
	
	public Attachment(){}
	
	public String getAttachmentName() 
	{
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) 
	{
		this.attachmentName = attachmentName;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public byte[] getAttchmentBytes() {
		return attchmentBytes;
	}

	public void setAttchmentBytes(byte[] attchmentBytes) {
		this.attchmentBytes = attchmentBytes;
	}

}