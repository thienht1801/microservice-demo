package com.ge.ev.Notification.model;

import java.io.Serializable;


public class Recipient implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7521683515492059826L;

	private String email;

	private String recipientName;
	
	private String type;
	
	public Recipient(){}
	
	public String getEmail() 
	{
		return email;
	}
	
	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	public String getRecipientName() 
	{
		return recipientName;
	}
	
	public void setRecipientName(String recipientName) 
	{
		this.recipientName = recipientName;
	}
	
	public String getType() 
	{
		return type;
	}
	
	public void setType(String type) 
	{
		this.type = type;
	}
}