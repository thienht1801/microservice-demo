package com.ge.ev.Notification.api.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ge.ev.Notification.api.INotification;
import com.ge.ev.Notification.model.Attachment;
import com.ge.ev.Notification.model.AttachmentResource;
import com.ge.ev.Notification.model.Header;
import com.ge.ev.Notification.model.Message;
import com.ge.ev.Notification.model.Recipient;

public class Notification implements INotification{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8237549385856542271L;
	private static Logger log = LoggerFactory.getLogger(Notification.class);
	
	private final Message message;
	
	public Notification()
	{
		this.message = new Message();
	}
	
	@Override
	public void setFrom(String fromName, String fromEmail) throws Exception
	{
		this.getMessage().setFromName(fromName);
		this.getMessage().setFromEmail(fromEmail);
	}

	@Override
	public void setRecipient(String recipientName, String recipientEmail, String recipientType) throws Exception
	{
		Recipient recipient = new Recipient();
		recipient.setRecipientName(recipientName);
		recipient.setEmail(recipientEmail);
		recipient.setType(recipientType);
		
		this.getMessage().getRecipients().add(recipient);
	}

	@Override
	public void setHeader(String key, String value) throws Exception 
	{
		Header header = new Header(key, value);
		this.getMessage().getHeaders().add(header);
	}

	@Override
	public void setSubject(String subject) throws Exception 
	{
		this.getMessage().setSubject(subject);
	}

	@Override
	public void setAttachment(String attachmentName, String attachmentExtn, String contentType, AttachmentResource attachmentResource) throws Exception 
	{
		Attachment attachment = new Attachment();
		attachment.setAttachmentName(attachmentName);
		attachment.setExtension(attachmentExtn);
		attachment.setContentType(contentType);
		attachment.setAttchmentBytes(serialize(attachmentResource));
		this.getMessage().getAttachments().add(attachment);
	}
	
	@Override
	public void setMessageType(String messageType) {
		this.getMessage().setMessageType(messageType);
	}

	@Override
	public void setMessageImportant(boolean important) {
		this.getMessage().setImportant(important);
	}

	@Override
	public void setMessageBody(String messageBody) {
		this.getMessage().setBody(messageBody);
	}

	

	private Message getMessage() {
		return message;
	}
	
	public boolean sendEmail(String notificationUrl) 
	{
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders httpHeaders = new HttpHeaders();
		List<Header> headersList = this.getMessage().getHeaders();
		HttpStatus statusCode = null;
		if(headersList != null)
		{
			for (Header header : headersList) 
			{
				httpHeaders.add(header.getKey(), header.getValue());
			}
		}
		
		HttpEntity<?> httpEntity = new HttpEntity<>(this.getMessage(),  httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<Map> response = restTemplate.exchange(notificationUrl, HttpMethod.POST, httpEntity, Map.class);
		if(response != null)
		{
			statusCode = response.getStatusCode();
		}
		
		log.info("Notification - sendEmail() - response status code: " + statusCode);
		
        if (statusCode != null && statusCode == HttpStatus.ACCEPTED)
        {
        	return true;
        }
        else
        {
            log.info("Notification - sendEmail() - response status code: " + statusCode);
            return false;
        }
	}

	public byte[] serialize(Object obj) throws IOException 
	{
        try(ByteArrayOutputStream b = new ByteArrayOutputStream())
        {
            try(ObjectOutputStream o = new ObjectOutputStream(b))
            {
                o.writeObject(obj);
            }
            return b.toByteArray();
        }
    }

	@Override
	public void setAppDomain(String appDomain) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setAuditTrial(boolean audit) throws Exception {
		// TODO Auto-generated method stub
		
	}
}