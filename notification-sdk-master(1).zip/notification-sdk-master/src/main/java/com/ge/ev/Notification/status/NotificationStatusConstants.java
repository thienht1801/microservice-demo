package com.ge.ev.Notification.status;

public final class NotificationStatusConstants {

	public static final int GENERAL_ERROR_VAL = -1;
	public static final String GENERAL_ERROR_STR = "Service general error";
	
    public static final int OK_1000_VAL = 1000;
    public static final String OK_1000_STR = "OK";
    
    public static final int NOTIFICATION_CONFIGURATION_DOES_NOT_EXIST_1001_VAL = 1001;
    public static final String NOTIFICATION_CONFIGURATION_DOES_NOT_EXIST_1001_STR = "Notification configuration does not exist";
        
    public static final int NOTIFICATION_TENANT_DOES_NOT_EXIST_1002_VAL = 1002;
    public static final String NOTIFICATION_TENANT_DOES_NOT_EXIST_1002_STR = "Notification Tenant does not exist";
    
    public static final int NOTIFICATION_SEND_ERROR_1003_VAL = 1003;
    public static final String NOTIFICATION_SEND_ERROR_1003_STR = "Encountered exception sending notifications";
    
    public static final int NOTIFICATION_TENANT_ID_MISMATCH_1004_VAL = 1004;
    public static final String NOTIFICATION_TENANT_ID_MISMATCH_1004_STR = "Tenant ID mismatch";
    
    public static final int NOTIFICATION_TENANT_MISSING_1005_VAL = 1005;
    public static final String NOTIFICATION_TENANT_MISSING_1005_STR = "Tenant is missing or blank";
    
    public static final int NOTIFICATION_SEARCH_QUERY_MISSING_1006_VAL = 1006;
    public static final String NOTIFICATION_SEARCH_QUERY_MISSING_1006_STR = "Search query is missing or blank";
    
    public static final int NOTIFICATION_INVALID_SEARCH_QUERY_STRING_1007_VAL = 1007;
    public static final String NOTIFICATION_INVALID_SEARCH_QUERY_STRING_1007_STR = "Invalid search query string";
    
    public static final int NOTIFICATION_CONFIGURATION_ADD_ERROR_1008_VAL = 1008;
    public static final String NOTIFICATION_CONFIGURATION_ADD_ERROR_1008_STR = "Encountered exception adding Configurations";
    
    public static final int NOTIFICATION_CONFIGURATION_PAYLOAD_LIMIT_STRING_1009_VAL = 1009;
    public static final String NOTIFICATION_CONFIGURATION_PAYLOAD_LIMIT_STRING_1009_STR = "Configurations payload has exceeded the set limit";
    
    public static final int NOTIFICATION_CONFIGURATION_TENANT_ID_MISMATCH_1010_VAL = 1010;
    public static final String NOTIFICATION_CONFIGURATION_TENANT_ID_MISMATCH_1010_STR = "Configuration Tenant ID mismatch";
    
    public static final int NOTIFICATION_CONFIGURATION_EMAIL_VALIDATION_1011_VAL = 1011;
    public static final String NOTIFICATION_CONFIGURATION_EMAIL_VALIDATION_1011_STR = "Email message validation failed";
    
    public static final int NOTIFICATION_EMAIL_MESSAGE_VALIDATION_1012_VAL = 1012;
    public static final String NOTIFICATION_EMAIL_MESSAGE_VALIDATION_1012_STR = "Email message validation failed";
    
    public static final int NOTIFICATION_EMAIL_MESSAGE_QUEUED_1013_VAL = 1013;
    public static final String NOTIFICATION_EMAIL_MESSAGE_QUEUED_1013_STR = "Email message is queued";

    public static final int NOTIFICATION_EMAIL_DAILY_LIMIT_REACHED_1014_VAL = 1014;
    public static final String NOTIFICATION_EMAIL_DAILY_LIMIT_REACHED_1014_STR = "Daily email limit reached";

    public static final int NOTIFICATION_EMAIL_MONTHLY_LIMIT_REACHED_1015_VAL = 1015;
    public static final String NOTIFICATION_EMAIL_MONTHLY_LIMIT_REACHED_1015_STR = "Monthly email limit reached";

    public static final int NOTIFICATION_GENERAL_ERROR_1016_VAL = 1016;
    public static final String NOTIFICATION_GENERAL_ERROR_1016_STR = "General failure";
    
    public static final int NOTIFICATION_EMAIL_ATTACHMENT_ERROR_1017_VAL = 1017;
    public static final String NOTIFICATION_EMAIL_ATTACHMENT_ERROR_1017_STR = "Email attachment(s) validation failed";

    public static final int NOTIFICATION_EMAIL_WEBHOOK_OK_1018_VAL = 1018;
    public static final String NOTIFICATION_EMAIL_WEBHOOK_OK_1018_STR = "Webhook successful";


    public static final int NOTIFICATION_EMAIL_WEBHOOK_FAIL_1019_VAL = 1019;
    public static final String NOTIFICATION_EMAIL_WEBHOOK_FAIL_1019_STR = "Webhook failed";
    
    public static final int NOTIFICATION_CONFIGURATION_TENANT_LIMIT_1020_VAL = 1020;
    public static final String NOTIFICATION_CONFIGURATION_TENANT_LIMIT_1020_STR = "Number of configurations limit per tenant is exceeded.";
    
    public static final int NOTIFICATION_EMAILS_PER_TENANT_LIMIT_1021_VAL = 1021;
    public static final String NOTIFICATION_EMAILS_PER_TENANT_LIMIT_1021_STR = "Exceeded number of emails limit per minute. Please try sending after sometime.";

    public static final int NOTIFICATION_TEMPLATE_DOES_NOT_EXIST_1022_VAL = 1022;
    public static final String NOTIFICATION_TEMPLATE_DOES_NOT_EXIST_1022_STR = "Notification template does not exist.";
    
    public static final int NOTIFICATION_TEMPLATE_MATCHERS_DOES_NOT_EXIST_1023_VAL = 1023;
    public static final String NOTIFICATION_TEMPLATE_MATCHERS_DOES_NOT_EXIST_1023_STR = "Notification template matchers does not exist.";
    
    public static final int NOTIFICATION_TEMPLATE_MATCHERS_INVALID_END_DATE_1024_VAL = 1024;
    public static final String NOTIFICATION_TEMPLATE_MATCHERS_INVALID_END_DATE_1024_STR = "Notification template matchers end date is not valid.";
  
    public static final int NOTIFICATION_TEMPLATE_MATCHERS_RECIPIENT_DOES_NOT_EXIST_1025_VAL = 1025;
    public static final String NOTIFICATION_TEMPLATE_MATCHERS_RECIPIENT_DOES_NOT_EXIST_1025_STR = "Notification template matchers recipient does not exist.";

    public static final int NOTIFICATION_TEMPLATE_MATCHERS_RECIPIENT_ALREADY_EXIST_1026_VAL = 1026;
    public static final String NOTIFICATION_TEMPLATE_MATCHERS_RECIPIENT_ALREADY_EXIST_1026_STR = "Notification template matchers recipient already exist.";
  
    public static final int NOTIFICATION_TEMPLATE_MATCHERS_RECIPIENT_INVALID_END_DATE_1027_VAL = 1027;
    public static final String NOTIFICATION_TEMPLATE_MATCHERS_RECIPIENT_INVALID_END_DATE_1027_STR = "Notification template matchers recipient end date is invalid.";
    
    public static final int NOTIFICATION_TEMPLATE_SUBCRIPTION_NAME_REQUIRED_1028_VAL = 1028;
    public static final String NOTIFICATION_TEMPLATE_SUBCRIPTION_NAME_REQUIRED_1028_STR = "Subcription (Notification template) name is required.";

    public static final int NOTIFICATION_TEMPLATE_SUBCRIPTION_DOMAIN_REQUIRED_1029_VAL = 1029;
    public static final String NOTIFICATION_TEMPLATE_SUBCRIPTION_DOMAIN_REQUIRED_1029_STR = "Subcription (Notification template) domain is required.";

    public static final int NOTIFICATION_TEMPLATE_UBCRIPTION_INVALID_END_DATE_1030_VAL = 1027;
    public static final String NOTIFICATION_TEMPLATE_UBCRIPTION_INVALID_END_DATE_1030_STR = "Subcription (Notification template) end date is invalid.";
    
    public static final int NOTIFICATION_TEMPLATE_SUBCRIPTION_NAME_ALREADY_EXISTS_1031_VAL = 1031;
    public static final String NOTIFICATION_TEMPLATE_SUBCRIPTION_NAME_ALREADY_EXISTS_1031_STR = "Subcription (Notification template) name already exist.";
    
    public static final int NOTIFICATION_TEMPLATE_SUBCRIPTION_DOES_NOT_EXISTS_1032_VAL = 1032;
    public static final String NOTIFICATION_TEMPLATE_SUBCRIPTION_DOES_NOT_EXISTS_1032_STR = "Subcription (Notification template) does not exist.";
    
    
}