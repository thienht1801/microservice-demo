package com.ge.ev.Notification.model;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Arrays;

import org.springframework.core.io.AbstractResource;

/*
 * AttachmentResource similar to ByteArrayResource implementation.
 * Need to do this because ByteArrayResource is not serializable.
 */
public class AttachmentResource extends AbstractResource implements Serializable{

	private final byte[] byteArray;

	private final String description;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1289713304697042803L;

	/**
	 * Create a new ByteArrayResource.
	 * @param byteArray the byte array to wrap
	 */
	public AttachmentResource(byte[] byteArray) {
		this(byteArray, "resource loaded from byte array");
	}

	/**
	 * Create a new ByteArrayResource.
	 * @param byteArray the byte array to wrap
	 * @param description where the byte array comes from
	 */
	public AttachmentResource(byte[] byteArray, String description) {
		if (byteArray == null) {
			throw new IllegalArgumentException("Byte array must not be null");
		}
		this.byteArray = byteArray;
		this.description = (description != null ? description : "");
	}

	/**
	 * Return the underlying byte array.
	 */
	public final byte[] getByteArray() {
		return this.byteArray;
	}


	/**
	 * This implementation always returns {@code true}.
	 */
	@Override
	public boolean exists() {
		return true;
	}

	/**
	 * This implementation returns the length of the underlying byte array.
	 */
	@Override
	public long contentLength() {
		return this.byteArray.length;
	}

	/**
	 * This implementation returns a ByteArrayInputStream for the
	 * underlying byte array.
	 * @see java.io.ByteArrayInputStream
	 */
	@Override
	public InputStream getInputStream() throws IOException {
		return new ByteArrayInputStream(this.byteArray);
	}

	/**
	 * This implementation returns a description that includes the passed-in
	 * {@code description}, if any.
	 */
	@Override
	public String getDescription() {
		return "Byte array resource [" + this.description + "]";
	}


	/**
	 * This implementation compares the underlying byte array.
	 * @see java.util.Arrays#equals(byte[], byte[])
	 */
	@Override
	public boolean equals(Object obj) 
	{
		boolean equality = false;
		
		if(obj == this)
		{
			equality = true;
		}
		
		if(obj instanceof AttachmentResource)
		{
			equality = Arrays.equals(((AttachmentResource) obj).byteArray, this.byteArray);
		}
		
		/*
		 * Code changes based on security scan... 
		 * return (obj == this || (obj instanceof ByteArrayResource && Arrays.equals(((AttachmentResource) obj).byteArray, this.byteArray)));
		 */
		
		return equality;
	}

	/**
	 * This implementation returns the hash code based on the
	 * underlying byte array.
	 */
	@Override
	public int hashCode()
	{
		return byte[].class.hashCode() * 29 * this.byteArray.length;
	}
}