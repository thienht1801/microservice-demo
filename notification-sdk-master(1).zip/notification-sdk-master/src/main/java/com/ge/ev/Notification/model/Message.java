package com.ge.ev.Notification.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/*
 * Main email message class
 */
public class Message implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7605529972876386241L;

	private String body;

	private String subject;

	private String fromEmail;

	private String fromName;

	private List<Recipient> recipients = new ArrayList<Recipient>();

	private Boolean important;

	private List<Header> headers = new ArrayList<Header>();

	private List<Attachment> attachments = new ArrayList<Attachment>();

	private String messageType;

	private String mailReturnPath;

	private MailConfiguration mailConfiguration;

	public Message() {
	}

	public enum toType implements Serializable {
		to, cc, bcc;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public List<Recipient> getRecipients() {
		return recipients;
	}

	public void setRecipients(List<Recipient> recipients) {
		this.recipients = recipients;
	}

	public Boolean getImportant() {
		return important;
	}

	public void setImportant(Boolean important) {
		this.important = important;
	}

	public List<Header> getHeaders() {
		return headers;
	}

	public void setHeaders(List<Header> headers) {
		this.headers = headers;
	}

	public List<Attachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<Attachment> attachments) {
		this.attachments = attachments;
	}

	public String getMailReturnPath() {
		return mailReturnPath;
	}

	public void setMailReturnPath(String mailReturnPath) {
		this.mailReturnPath = mailReturnPath;
	}

	public MailConfiguration getMailConfiguration() {
		return mailConfiguration;
	}

	public void setMailConfiguration(MailConfiguration mailConfiguration) {
		this.mailConfiguration = mailConfiguration;
	}

	@JsonIgnore
	public List<String> getRecipientsEmails()
	{
		List<String> emails = new ArrayList<>();
		if (recipients != null)
		{
			for (Recipient recipient : recipients)
			{
				emails.add(recipient.getEmail());
			}
		}
		return emails;
	}

}