package com.ge.ev.Notification.model.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.ev.Notification.model.Attachment;

@RunWith(MockitoJUnitRunner.class)
public class AttachmentTest {
	@Mock
	Attachment attachmentMock;

	@Before
	public void init() {
		attachmentMock = new Attachment();
		attachmentMock.setAttachmentName("attachmentName");
		attachmentMock.setContentType("contentType");
		attachmentMock.setExtension("extension");
	}

	@Test
	public void testAttachment() {
		assertNotNull(attachmentMock.getAttachmentName());
		assertNotNull(attachmentMock.getContentType());
		assertNotNull(attachmentMock.getExtension());
	}

	@After
	public void clean() {
		attachmentMock = null;
	}
}