package com.ge.ev.Notification.model.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.ev.Notification.model.Header;

@RunWith(MockitoJUnitRunner.class)
public class HeaderTest {
	@Mock
	Header headerMock;

	@Before
	public void init() {
		headerMock = new Header();
		headerMock.setKey("key");
		headerMock.setValue("value");
	}

	@Test
	public void testHeader() {
		assertNotNull(headerMock);
		assertNotNull(headerMock.getKey());
		assertNotNull(headerMock.getValue());
	}
	
	@After
	public void clean()
	{
		headerMock = null;
	}
}