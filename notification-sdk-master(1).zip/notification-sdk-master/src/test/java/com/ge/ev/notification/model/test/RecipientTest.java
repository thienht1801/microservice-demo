package com.ge.ev.Notification.model.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.ev.Notification.model.Recipient;

@RunWith(MockitoJUnitRunner.class)
public class RecipientTest {
	@Mock
	Recipient recipientMock;

	@Before
	public void init() 
	{
		recipientMock = new Recipient();
		recipientMock.setEmail("email");
		recipientMock.setRecipientName("recipientName");
		recipientMock.setType("type");
	}
	
	@Test
	public void testRecipient() {
		assertNotNull(recipientMock);
		assertNotNull(recipientMock.getEmail());
		assertNotNull(recipientMock.getRecipientName());
		assertNotNull(recipientMock.getType());
	}
	
	@After
	public void clean()
	{
		recipientMock = null;
	}
}