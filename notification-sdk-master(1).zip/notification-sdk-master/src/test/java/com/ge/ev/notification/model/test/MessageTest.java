package com.ge.ev.Notification.model.test;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.ev.Notification.model.Attachment;
import com.ge.ev.Notification.model.Header;
import com.ge.ev.Notification.model.MailConfiguration;
import com.ge.ev.Notification.model.Message;
import com.ge.ev.Notification.model.Recipient;

@RunWith(MockitoJUnitRunner.class)
public class MessageTest {
	
	@Mock
	Message messageMock;
	
	@Before
	public void init() 
	{
		messageMock = new Message();
		messageMock.setAttachments(getAttachmentList());
		messageMock.setBody("Body");
		messageMock.setFromEmail("fromEmail");
		messageMock.setFromName("fromName");
		messageMock.setHeaders(getHeaderList());
		messageMock.setImportant(true);
		messageMock.setMailConfiguration(getMailConfiguration());
		messageMock.setMailReturnPath("mailReturnPath");
		messageMock.setMessageType("messageType");
		messageMock.setRecipients(getRecipientList());
		messageMock.setSubject("subject");
	}
	
	@Test
	public void testMessage() 
	{
		assertNotNull(messageMock);
		assertNotNull(messageMock.getAttachments());
		assertNotNull(messageMock.getBody());
		assertNotNull(messageMock.getFromEmail());
		assertNotNull(messageMock.getFromName());
		assertNotNull(messageMock.getHeaders());
		assertNotNull(messageMock.getImportant());
		assertNotNull(messageMock.getMailConfiguration());
		assertNotNull(messageMock.getMailReturnPath());
		assertNotNull(messageMock.getMessageType());
		assertNotNull(messageMock.getRecipients());
		assertNotNull(messageMock.getRecipientsEmails());
		assertNotNull(messageMock.getSubject());
	}

	private MailConfiguration getMailConfiguration()
	{
		MailConfiguration mailConfiguration = new MailConfiguration();
		mailConfiguration.setHost("host");
		mailConfiguration.setMailFrom("mailFrom");
		mailConfiguration.setMailPassword("mailPassword");
		mailConfiguration.setMailReturnPath("mailReturnPath");
		return mailConfiguration;
	}
	
	private List<Attachment> getAttachmentList()
	{
		List<Attachment> attachmentList = new ArrayList<Attachment>();
		attachmentList.add(getAttachment());
		return attachmentList;
	}
	
	private Attachment getAttachment()
	{
		Attachment attachment = new Attachment();
		attachment.setAttachmentName("attachmentName");
		attachment.setContentType("text");
		attachment.setExtension("extension");
		return attachment;
	}
	
	private List<Header> getHeaderList()
	{
		List<Header> headerList = new ArrayList<Header>();
		headerList.add(getHeader());
		return headerList;
	}
	
	private Header getHeader()
	{
		Header header = new Header();
		header.setKey("key");
		header.setValue("value");
		return header;
	}
	
	private List<Recipient> getRecipientList()
	{
		List<Recipient> recipientList = new ArrayList<Recipient>();
		recipientList.add(getRecipient());
		return recipientList;
	}
	
	private Recipient getRecipient()
	{
		Recipient recipient =new Recipient();
		recipient.setEmail("email");
		recipient.setRecipientName("recipientName");
		recipient.setType("type");
		return recipient;
	}
}
