package com.ge.ev.Notification.api.impl.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.ev.Notification.api.impl.Notification;
import com.ge.ev.Notification.model.AttachmentResource;

@RunWith(MockitoJUnitRunner.class)
public class NotificationTest {
	
	@Mock
	Notification notificationMock;
	
	@Before
	public void init() 
	{
		notificationMock = new Notification();
	}

	@Test
	public void testNotification()
	{
		try
		{
			assertNotNull(notificationMock);
			notificationMock.setFrom("NotificationFromName", "NotificationFromEmail");
			notificationMock.setRecipient("NotificationRecipientName", "NotificationRecipientEmail", "NotificationRecipientType");
			notificationMock.setHeader("NotificationKey", "NotificationValue");
			notificationMock.setSubject("NotificationSubject");
			notificationMock.setMessageType("text");
			notificationMock.setMessageImportant(true);
			notificationMock.setMessageBody("NotificationBody");
			notificationMock.serialize("serializeMe");
			//notificationMock.sendEmail("http://www.google.com");		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//e.getMessage();
		}
	}
	
	@After
	public void clean()
	{
		notificationMock = null;
	}
}