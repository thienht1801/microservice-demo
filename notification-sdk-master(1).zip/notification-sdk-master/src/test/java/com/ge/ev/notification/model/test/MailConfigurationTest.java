package com.ge.ev.Notification.model.test;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import static org.junit.Assert.assertNotNull;
import com.ge.ev.Notification.model.MailConfiguration;

@RunWith(MockitoJUnitRunner.class)
public class MailConfigurationTest {

	@Mock
	MailConfiguration mailConfigurationMock;
	
	@Before
	public void init() {
		mailConfigurationMock = new MailConfiguration();
		mailConfigurationMock.setHost("host");
		mailConfigurationMock.setMailFrom("mailFrom");
		mailConfigurationMock.setMailPassword("mailPassword");
		mailConfigurationMock.setMailReturnPath("mailReturnPath");
		mailConfigurationMock.setMailUsername("mailUsername");
		mailConfigurationMock.setPort(100);
		mailConfigurationMock.setProtocol("protocol");
		mailConfigurationMock.setSmtpAuth("smtpAuth");
		mailConfigurationMock.setSmtpStarttlsEnable("smtpStarttlsEnable");
	}
	
	@Test
	public void testMailConfiguration() {
		assertNotNull(mailConfigurationMock);
		assertNotNull(mailConfigurationMock.getHost());
		assertNotNull(mailConfigurationMock.getMailFrom());
		assertNotNull(mailConfigurationMock.getMailPassword());
		assertNotNull(mailConfigurationMock.getMailReturnPath());
		assertNotNull(mailConfigurationMock.getMailUsername());
		assertNotNull(mailConfigurationMock.getPort());
		assertNotNull(mailConfigurationMock.getProtocol());
		assertNotNull(mailConfigurationMock.getSmtpAuth());
		assertNotNull(mailConfigurationMock.getSmtpStarttlsEnable());
	}
}