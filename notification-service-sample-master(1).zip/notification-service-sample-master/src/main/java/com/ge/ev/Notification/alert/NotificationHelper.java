package com.ge.ev.Notification.alert;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.ev.Notification.model.Attachment;
import com.ge.ev.Notification.model.Header;
import com.ge.ev.Notification.model.Message;
import com.ge.ev.Notification.model.Recipient;

/**
 * Helper implementation for Email message building.
 * @author 212341178
 */

@Component
public class NotificationHelper {
	
	private static Logger log = LoggerFactory.getLogger(NotificationHelper.class);
	
	@Value("${mailFromEmail}")
	private String fromEmail;
	
	@Value("${mailFromName}")
	private String fromName;
	
	@Value("${mailBody}")
	private String body;
	
	@Value("${mailImportant}")
	private String important;
	
	@Value("${mailMessageType}")
	private String messageType;
	
	@Value("${mailRecipientTo}")
	private String recipient_to;
	
	@Value("${mailRecipientToName}")
	private String recipient_to_name;
	
	@Value("${mailRecipientCc}")
	private String recipient_cc;
	
	@Value("${mailRecipientCcName}")
	private String recipient_cc_name;
	
	@Value("${mailRecipientBcc}")
	private String recipient_bcc;
	
	@Value("${mailRecipientBccName}")
	private String recipient_bcc_name;
	
	@Value("${mailSubject}")
	private String subject;
	
	@Value("${mailAttachmentPath}")
	private String attachmentPath;
	
	@Value("${mailAttachmentExtn}")
	private String attachmentExtn;
	
	@Value("${mailAttachmentName}")
	private String attachmentName;
	
	@Value("${mailAttachmentContenttype}")
	private String attachmentContentType;	
			
	private static final String EMPTY_STRING = "";
	
	public Message buildMessage() 
	{
		Message message = null;
		try 
		{
			message = new Message();

			message.setFromEmail(fromEmail);
			message.setFromName(fromName);
			message.setBody(body);
			message.setSubject(subject);
			message.setImportant((important != null && "true".equalsIgnoreCase(important)) ? true : false);
			message.setMessageType(messageType);
			
			List<Header> headerList = new ArrayList<Header>();
			Header header = new Header("Date", ((Date) Calendar.getInstance().getTime()).toString());
			headerList.add(header);
			message.setHeaders(headerList);

			List<Recipient> recipientList = new ArrayList<Recipient>();

			if (recipient_to != null && !EMPTY_STRING.equals(recipient_to.trim()))
			{
				List<String> recipientTOList = Arrays.asList(recipient_to.split(","));
				for (String recipient : recipientTOList)
				{
					Recipient recp = new Recipient();
					recp.setEmail(recipient);
					recp.setRecipientName(recipient_to_name);
					recp.setType("to");
					recipientList.add(recp);
				}
			}

			if (recipient_cc != null && !EMPTY_STRING.equals(recipient_cc.trim()))
			{
				List<String> recipientCCList = Arrays.asList(recipient_cc.split(","));
				for (String recipient : recipientCCList)
				{
					Recipient recp = new Recipient();
					recp.setEmail(recipient);
					recp.setRecipientName(recipient_cc_name);
					recp.setType("cc");
					recipientList.add(recp);
				}
			}
			
			if (recipient_bcc != null && !EMPTY_STRING.equals(recipient_bcc.trim()))
			{
				List<String> recipientBCCList = Arrays.asList(recipient_bcc.split(","));
				for (String recipient : recipientBCCList)
				{
					Recipient recp = new Recipient();
					recp.setEmail(recipient);
					recp.setRecipientName(recipient_cc_name);
					recp.setType("bcc");
					recipientList.add(recp);
				}
			}

			log.info("recipientList : " + recipientList);
			
			message.setRecipients(recipientList);

			//Attachments.
			List<Attachment> attachmentList = new ArrayList<Attachment>();
			message.setAttachments(attachmentList);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}
	
	public static byte[] serialize(Object obj) throws IOException 
	{
        try(ByteArrayOutputStream b = new ByteArrayOutputStream())
        {
            try(ObjectOutputStream o = new ObjectOutputStream(b))
            {
                o.writeObject(obj);
            }
            return b.toByteArray();
        }
    }

    public static Object deserialize(byte[] bytes) throws IOException, ClassNotFoundException 
    {
        try(ByteArrayInputStream b = new ByteArrayInputStream(bytes))
        {
            try(ObjectInputStream o = new ObjectInputStream(b))
            {
                return o.readObject();
            }
        }
    }
    
    public static Long getSize(HttpServletRequest request)
    {
       return request.getContentLengthLong();
    }
}
