package com.ge.ev.Notification.alert;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ev.Notification.model.Message;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.config.AuthSchemes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class NotificationService {
	private static Logger log = LoggerFactory.getLogger(NotificationService.class);

	RestTemplate restTemplate;

	private static final String OAUTH_TOKEN_BEARER = "Bearer ";

	private final static String UAA_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSX";

	private final static String OAUTH_TOKEN_ENDPOINT = "/oauth/token";

	private final static String OAUTH_GRANT_TYPE = "client_credentials";

    @Value("${mailAlertUrl}")
    private String alertUrl;

    @Value("${mailBaseUrl}")
    private String baseUrl;
    
    @Value("${mailBatchClientId}")
    private String batchClientId;
    
    @Value("${mailBatchClientS5cr5t}")
    private String batchClientS5cr5t;    

	public String notify(Message mailMessage) 
	{
		log.info("inside the notifyAlertService of AlertNotification...... alertUrl is :" + alertUrl);
		log.info("Sending mail message request for " + mailMessage);

		try 
		{
			restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.add(org.apache.http.HttpHeaders.AUTHORIZATION, OAUTH_TOKEN_BEARER + getOAuthToken());

			HttpEntity<?> entity = new HttpEntity<>(mailMessage, headers);
			restTemplate.exchange(alertUrl, HttpMethod.POST, entity, Map.class);
			log.info("Successfully sent email...");
		} 
		catch (Exception e) 
		{
			log.info("Failed in notifyAlertService: " + e.getMessage());
			e.printStackTrace();
		}
		return "Success";
	}

	public String getAlertUrl() {
		return alertUrl;
	}

	public void setAlertUrl(String alertUrl) {
		this.alertUrl = alertUrl;
	}

	private String getOAuthToken() {
		Assert.notNull(baseUrl);

		log.info("Obtaining an OAuth token from the UAA server..." + baseUrl);
		String basicDigestHeaderValue = AuthSchemes.BASIC + " "
				+ new String(Base64.encodeBase64((batchClientId + ":" + batchClientS5cr5t).getBytes()));
		HttpHeaders headers = new HttpHeaders();
		headers.set(org.apache.http.HttpHeaders.AUTHORIZATION, basicDigestHeaderValue);
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> formParams = new LinkedMultiValueMap<String, String>();
		formParams.add("grant_type", OAUTH_GRANT_TYPE);

		HttpEntity<MultiValueMap<String, String>> formEncodedRequest = new HttpEntity<MultiValueMap<String, String>>(formParams, headers);
		setMessageConverters(restTemplate);
		OAuthToken oauthToken = restTemplate.postForObject(baseUrl + OAUTH_TOKEN_ENDPOINT, formEncodedRequest, OAuthToken.class);

		log.info("Successfully obtained OAuth token from UAA server");

		if (oauthToken != null) {
			return oauthToken.accessToken;
		} else {
			return null;
		}
	}

	private void setMessageConverters(RestTemplate restTemplate) {
		// For Date Marshalling/Unmarshalling
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setDateFormat(new SimpleDateFormat(UAA_DATE_FORMAT));

		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		MappingJackson2HttpMessageConverter httpMessageConverter = new MappingJackson2HttpMessageConverter();
		httpMessageConverter.setObjectMapper(objectMapper);
		messageConverters.add(httpMessageConverter);
		messageConverters.add(new FormHttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class OAuthToken {
		@JsonProperty("access_token")
		public String accessToken;

		public OAuthToken() {
		}
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getBatchClientId() {
		return batchClientId;
	}

	public void setBatchClientId(String batchClientId) {
		this.batchClientId = batchClientId;
	}

	public String getBatchClientS5cr5t() {
		return batchClientS5cr5t;
	}

	public void setBatchClientS5cr5t(String batchClientS5cr5t) {
		this.batchClientS5cr5t = batchClientS5cr5t;
	}

}