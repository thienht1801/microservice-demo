package com.ge.ev.Notification.alert.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.ev.Notification.alert.NotificationHelper;
import com.ge.ev.Notification.alert.NotificationService;
import com.ge.ev.Notification.model.Message;

@RestController
public class AlertEmailController 
{
	private static Logger log = LoggerFactory.getLogger(NotificationService.class);
	
	@Autowired
	NotificationHelper notificationHelper;
	
	@Autowired
	NotificationService notificationService;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "sendEmail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> sendEmail() throws Exception 
	{
		String result = null;
		try 
		{
			Message message = notificationHelper.buildMessage();
			result = notificationService.notify(message);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return new ResponseEntity(result, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("result is : " + result);
		
		return new ResponseEntity(result, HttpStatus.OK);
	}
}